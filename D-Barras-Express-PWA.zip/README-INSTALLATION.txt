D-Barras Express — fichiers PWA

Contenu :
- manifest.json
- icons/icon-192.png
- icons/icon-512.png
- icons/icon-maskable-512.png

Installation dans le dépôt GitHub Pages :
1. Décompressez cette archive à la racine du dépôt, en conservant le dossier icons.
2. Dans le <head> de votre index.html, ajoutez :

<link rel="manifest" href="./manifest.json">
<meta name="theme-color" content="#031233">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<link rel="apple-touch-icon" href="./icons/icon-192.png">

3. Vérifiez que les fichiers sont accessibles aux adresses :
   /D-barras-Express/manifest.json
   /D-barras-Express/icons/icon-192.png
   /D-barras-Express/icons/icon-512.png
   /D-barras-Express/icons/icon-maskable-512.png

Note : le manifest permet l'installation PWA, mais l'expérience d'installation complète
peut aussi nécessiter un service worker selon le navigateur et les fonctionnalités souhaitées.
